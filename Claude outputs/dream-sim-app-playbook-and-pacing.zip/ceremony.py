"""The ceremony (Segment E).

One pattern recurs six times across the journey:

    a playbook is drafted  ->  you sign it  ->  your face is captured
                           ->  you enter as verified

It happens before a date, before contact details are shared, before a home
visit, at Relationship entry, and at each stage checkpoint. Building it six
times would mean six places to get the rules slightly different in; this is
the single parameterised version, and the kind is the only thing that
varies.

Naming rule (docs/CLAUDE.md): never the word "contract" in identifiers or
messages — these are playbooks, plans and agreements of understanding.

WHAT THIS IS NOT
================
The face capture is a stub. `capture_face()` records that the step was
taken; it does not look at anything, and nothing here should be described
to a user as identity verification. Real liveness is Phase 9 of the
roadmap. The signature is a typed name, which is a record of intent, not
a legally binding instrument — docs say these agreements are guidelines,
and the copy must keep saying so.

Pure functions. The caller persists Ceremony rows.
"""

from __future__ import annotations

import json
from typing import Any

# ── the four steps, always in this order ──────────────────────────────────

PLAYBOOK = "playbook"
SIGN = "sign"
FACE = "face"
DONE = "done"

STEPS = [
    (PLAYBOOK, "Read the playbook"),
    (SIGN, "Sign it"),
    (FACE, "Confirm it is you"),
    (DONE, "Enter as verified"),
]
STEP_KEYS = [key for key, _ in STEPS]


# ── the six occasions ─────────────────────────────────────────────────────
# `scope` names what the ceremony is ABOUT, so the same kind can happen
# again for a different date, a different stage, a different invitation.
# `fee` links to payments.py where one applies; None means free.

DATE_AGREEMENT = "date_agreement"
CONTACT_SHARE = "contact_share"
HOME_INVITE = "home_invite"
RELATIONSHIP_ENTRY = "relationship_entry"
STAGE_GATE = "stage_gate"

KINDS = {
    DATE_AGREEMENT: {
        "label": "Agreement of understanding",
        "blurb": "The terms for one evening, drawn from what you both already told us.",
        "scope": "one date",
        "fee": "agreement",
        "unlocks": "Your date is confirmed and prep opens.",
    },
    CONTACT_SHARE: {
        "label": "Sharing contact details",
        "blurb": "What you are handing over, and how to take it back.",
        "scope": "one exchange",
        "fee": None,
        "unlocks": "Numbers and handles become visible — to both of you, or neither.",
    },
    HOME_INVITE: {
        "label": "Invitation home",
        "blurb": "Where you are going, who else knows, and what either of you can call off.",
        "scope": "one visit",
        "fee": None,
        "unlocks": "The invitation is sent, with your trusted contact informed.",
    },
    RELATIONSHIP_ENTRY: {
        "label": "Becoming exclusive",
        "blurb": "What changes when you stop seeing other people, said out loud.",
        "scope": "the relationship",
        "fee": None,
        "unlocks": "You enter the Relationship stage and Guru's four pillars begin.",
    },
    STAGE_GATE: {
        "label": "Stage checkpoint",
        "blurb": "What moving to the next stage means, and what it does not.",
        "scope": "one checkpoint",
        "fee": "stage_gate",
        "unlocks": "You both move to the next stage together.",
    },
}


# ── the terms each ceremony asks you to acknowledge ───────────────────────
# A signature that records only a name records agreement to nothing. These
# are the specific terms, spelt out, ticked one at a time — which is what
# makes the difference between signing a document and clicking through it.
#
# For the date agreement the four keys match dateplan.ACK_FIELDS exactly,
# so a completed ceremony can be mirrored into the Signature row the rest
# of the app already reads without inventing consent nobody gave.

ACKS: dict[str, list[tuple[str, str, str]]] = {
    DATE_AGREEMENT: [
        ("ack_conduct", "Code of conduct and courtesies",
         "I will greet them by name, keep my phone face-down, answer honestly, and "
         "respect the greeting preference on the record without comment."),
        # 2026-09-09: reworded away from "cancellation policy". The old
        # label read as a service being offered. It is a consequence.
        ("ack_cancellation", "Turning up",
         "I have paid for and am signing a confirmed slot. I understand that not appearing, "
         "or cancelling inside 24 hours of it, carries a charge and is recorded."),
        ("ack_not_a_relationship", "What this is not",
         "This is one meeting to establish whether a second is warranted. It creates no "
         "relationship, no exclusivity and no expectation beyond the evening."),
        ("ack_liability", "Platform liability",
         "Dare to Dream introduces people and records what they agree to. It does not "
         "supervise the meeting and is not responsible for what happens at it."),
    ],
    CONTACT_SHARE: [
        ("ack_onward", "No onward sharing",
         "I will use these details to contact them and nothing else — no lists, no "
         "forwarding, no looking them up elsewhere."),
        ("ack_revocable", "Either of us can take it back",
         "I understand either party may revoke at any time, that revoking hides the "
         "detail again, and that it cannot un-send anything already sent."),
        ("ack_no_obligation", "No obligation to reply",
         "Sharing a channel creates no expectation of a reply, a pace, or a continued "
         "exchange."),
    ],
    HOME_INVITE: [
        ("ack_someone_knows", "Someone outside this app knows",
         "I have told a trusted contact where I will be and when I expect to leave."),
        ("ack_callable_off", "Either of us can call it off",
         "I understand either party may cancel before or during, without explanation, "
         "and that it counts against neither of us."),
        ("ack_boundaries", "Boundaries stand",
         "Everything either of us recorded about pace and boundaries applies here "
         "exactly as it does anywhere else."),
    ],
    RELATIONSHIP_ENTRY: [
        ("ack_exclusive", "We both leave the pool",
         "I will not be shown to anyone else, and I will not be shown anyone else."),
        ("ack_not_legal", "This is not a legal instrument",
         "This is an agreement of understanding between two people. It creates no "
         "financial or legal tie."),
        ("ack_exit", "Leaving is allowed",
         "Either of us may exit. Exiting opens a private conversation with Guru and a "
         "cool-off period before returning to the pool."),
    ],
    STAGE_GATE: [
        ("ack_both", "Both of us, or neither",
         "I understand one opt-in advances nothing, and that nothing here is automatic."),
        ("ack_reversible", "Reaching a stage obliges nothing",
         "Nothing about this checkpoint is irreversible, and reaching a stage creates no "
         "obligation to reach the next one."),
        ("ack_honest", "Answered honestly",
         "A checkpoint passed to please the other person is worse than one not yet "
         "passed. My answers are my own."),
    ],
}


def acks_for(kind: str) -> list[dict[str, str]]:
    """The terms this kind asks you to tick, in order."""
    kind_meta(kind)
    return [{"key": k, "label": lbl, "term": term} for k, lbl, term in ACKS[kind]]


def ack_keys(kind: str) -> tuple[str, ...]:
    return tuple(k for k, _, _ in ACKS[kind])


def kind_meta(kind: str) -> dict[str, Any]:
    if kind not in KINDS:
        raise ValueError(f"Unknown ceremony kind {kind!r}; expected one of {sorted(KINDS)}")
    return KINDS[kind]


def new_state(user_id: str, kind: str, scope_id: str, created_at: str) -> dict[str, Any]:
    """The Ceremony row to persist when someone first opens one."""
    kind_meta(kind)
    return {
        "id": f"{user_id}:{kind}:{scope_id}",
        "user_id": user_id,
        "kind": kind,
        "scope_id": scope_id,
        "playbook_ack": 0,
        "signed_name": None,
        "signed_at": None,
        "face_verified": 0,
        "acks_json": "[]",
        "completed_at": None,
        "created_at": created_at,
    }


# ── progress ──────────────────────────────────────────────────────────────


def _truthy(value: Any) -> bool:
    """Rows come back as 0/1 from SQLite and as booleans from psycopg."""
    return bool(value)


def next_step(state: dict[str, Any]) -> str:
    """Which step is open now. Strictly ordered — you cannot sign a
    playbook you have not opened, and the route relies on that rather than
    trusting whichever form was posted."""
    if not _truthy(state.get("playbook_ack")):
        return PLAYBOOK
    if not state.get("signed_name"):
        return SIGN
    if not _truthy(state.get("face_verified")):
        return FACE
    return DONE


def is_complete(state: dict[str, Any]) -> bool:
    return next_step(state) == DONE


def progress(state: dict[str, Any]) -> list[dict[str, Any]]:
    """The step rail. Same shape as the onboarding wizard's, so the two
    read as the same product rather than two different ones."""
    current = next_step(state)
    current_index = STEP_KEYS.index(current)
    return [
        {
            "key": key,
            "label": label,
            "index": i + 1,
            "state": "done" if i < current_index else ("current" if i == current_index else "todo"),
        }
        for i, (key, label) in enumerate(STEPS)
    ]


def ack_playbook(state: dict[str, Any]) -> dict[str, Any]:
    return {**state, "playbook_ack": 1}


def signed_acks(state: dict[str, Any]) -> list[str]:
    """Which terms this signature actually ticked."""
    raw = state.get("acks_json") or "[]"
    if isinstance(raw, (list, tuple)):
        return list(raw)
    try:
        value = json.loads(raw)
    except (TypeError, ValueError):
        return []
    return list(value) if isinstance(value, list) else []


def missing_acks(state: dict[str, Any], ticked: list[str] | None = None) -> list[str]:
    """The terms still outstanding. `ticked` checks a proposed signature;
    omit it to check what is already stored."""
    given = set(ticked if ticked is not None else signed_acks(state))
    return [k for k in ack_keys(state["kind"]) if k not in given]


def sign(state: dict[str, Any], typed_name: str, acks: list[str], signed_at: str) -> dict[str, Any]:
    """Record the typed signature and the terms it agreed to.

    Three refusals, all returning the state untouched rather than a partial
    signature — an agreement that looks signed but is not is worse than one
    that is plainly unsigned:

      * a blank name,
      * a playbook that was never opened,
      * any term left unticked.

    The last is the point of this function. Ticking every box on the user's
    behalf, which is what the date flow used to do, records agreement
    nobody gave.
    """
    name = (typed_name or "").strip()
    if not name:
        return state
    if not _truthy(state.get("playbook_ack")):
        return state
    given = [k for k in ack_keys(state["kind"]) if k in set(acks or [])]
    if missing_acks(state, given):
        return state
    return {**state, "signed_name": name, "signed_at": signed_at,
            "acks_json": json.dumps(given)}


def capture_face(state: dict[str, Any]) -> dict[str, Any]:
    """STUB. Records that the step was taken. Nothing is looked at, and
    no user-facing copy should call this identity verification."""
    if not state.get("signed_name"):
        return state
    return {**state, "face_verified": 1}


def complete(state: dict[str, Any], completed_at: str) -> dict[str, Any]:
    if not is_complete(state):
        return state
    return {**state, "completed_at": state.get("completed_at") or completed_at}


def both_complete(states: list[dict[str, Any]], user_a: str, user_b: str) -> bool:
    """A ceremony binds two people. One signature is half of one."""
    done = {s["user_id"] for s in states if is_complete(s)}
    return user_a in done and user_b in done


# ── the playbooks ─────────────────────────────────────────────────────────
# Every clause is filled from what both people already told us. Nothing
# here is typed by hand, which is the point: the agreement is a readback,
# not a negotiation.


def date_clauses(ctx: dict[str, Any]) -> list[dict[str, str]]:
    """The date agreement, one clause per numbered section.

    2026-09-09: rebuilt against docs/DatePlaybookSample.pdf, which set out
    twelve sections against the seven that existed. Payment, safety,
    verification, dispute resolution, data and term were simply absent.

    Two departures from that document, both decided by the user:

    * CANCELLATION (its section 5) states the consequence and does not
      advertise the window. "Free with 24 hours' notice" printed on the
      screen where someone is being asked to commit is an invitation to
      back out, and the whole product exists because people commit too
      easily or not at all. The charge still applies; nothing sells it.

    * COMPLIANCE RATING (its section 7) is not written, because there is
      no rating system. Clause 7 says only what is true: a background
      check happened at sign-up, and feedback is recorded afterwards. An
      agreement whose premise is "this is a readback" cannot assert a
      mechanism that does not exist — the same mistake the bill clause
      made when it claimed a band nobody had declared.

    `ctx` carries the plan's own values; anything missing degrades to a
    readable placeholder rather than rendering None at someone.
    """
    slot = ctx.get("slot", "the agreed slot")
    meal = (ctx.get("meal") or "meal").lower()
    cuisine = ctx.get("cuisine") or "a cuisine you both eat"
    budget = ctx.get("budget") or "the band you both declared"
    split = ctx.get("bill_split") or "the split you both agreed"
    my_diet = ctx.get("my_diet") or "as declared"
    their_diet = ctx.get("their_diet") or "as declared"
    greeting = ctx.get("greeting")
    me = ctx.get("my_name") or "First party"
    them = ctx.get("partner_name") or "Second party"
    fee = ctx.get("cancellation_fee") or "a charge"
    notice = ctx.get("notice_hours") or 24

    courtesies = (
        "Greet each other by name. Phones face-down and silent throughout. Answer honestly, "
        "including \u201cI would rather not say\u201d."
    )
    if greeting:
        courtesies = (
            f"Greeting on the record: {greeting.replace('-', ' ')}, respected without comment. "
            + courtesies
        )

    return [
        {"n": "1", "title": "Who, and what this covers",
         "body": f"{me} and {them}, for one meeting arranged through Dare to Dream. It sits "
                 "under the dating-stage understanding between you and creates no relationship, "
                 "no exclusivity and no commitment beyond the evening itself."},
        {"n": "2", "title": "Time and place",
         "body": f"{slot} \u2014 {meal} at a {cuisine} venue convenient to both of you, confirmed "
                 "in advance. A public venue, chosen from the slot you both offered."},
        {"n": "3", "title": "Fees",
         "body": "The date fee is paid to the platform before this agreement opens, and it is "
                 "what puts these terms in front of you both. Neither of you sends money to the "
                 "other, for this booking or because of it."},
        {"n": "4", "title": "The bill",
         "body": f"You both declared a {budget} band. The bill is settled {split}, requested at "
                 "the table, and settled without contest. The method is fixed for this date "
                 "unless you both agree otherwise beforehand. Neither of you treats payment as "
                 "leverage."},
        {"n": "5", "title": "Dietary terms",
         "body": f"First party: {my_diet}. Second party: {their_diet}. The venue carries options "
                 "for both. No commentary on the other person's plate."},
        {"n": "6", "title": "Conduct",
         "body": courtesies + " Harassment, discrimination and abuse end the meeting and the "
                 "match. Nothing is recorded, photographed or posted without the other person "
                 "saying yes first. This meeting is not an occasion to solicit work, money or "
                 "anything else."},
        {"n": "7", "title": "Verification, and what happens after",
         "body": "This match was made on the strength of a background check completed at "
                 "sign-up, and you each confirm your details are still current. After the date "
                 "you each record feedback. It goes to Guru, not to each other."},
        {"n": "8", "title": "Not turning up",
         "body": f"You have both paid for and signed a confirmed slot. Not appearing, or "
                 f"cancelling inside {notice} hours of it, carries {fee} and is recorded. If "
                 "something genuinely prevents you attending, tell Guru rather than the door."},
        {"n": "9", "title": "Leaving early",
         "body": "Either of you may end the meeting at any point, without explanation, and is "
                 "seen safely to transport. This is not the same as not turning up and carries "
                 "nothing."},
        {"n": "10", "title": "Safety",
         "body": "Tell someone outside this app where you are going and when you expect to "
                 "leave. Anything that worries you \u2014 during or afterwards \u2014 is reported "
                 "through the app and read by a person."},
        {"n": "11", "title": "What the platform is",
         "body": "Dare to Dream introduces people, arranges the slot, and records what you both "
                 "agree to. It is not at the meeting, does not supervise it, and is not "
                 "responsible for what either of you does there. You are two adults meeting a "
                 "stranger; take the ordinary care that deserves. Anything unresolved comes to "
                 "Guru first."},
        {"n": "12", "title": "What is shared, and for how long",
         "body": "Only your names, verified badges and the confirmed venue and time pass between "
                 "you. Not your contact details, and not where you live. Nothing said at this "
                 "meeting is repeated, screenshotted or posted. This agreement covers the single "
                 "date in clause 2 and expires when it is over."},
    ]


def _simple_clauses(items: list[tuple[str, str]]) -> list[dict[str, str]]:
    return [{"n": str(i + 1), "title": t, "body": b} for i, (t, b) in enumerate(items)]


def clauses_for(kind: str, ctx: dict[str, Any] | None = None) -> list[dict[str, str]]:
    """The playbook for this kind of ceremony."""
    ctx = ctx or {}
    kind_meta(kind)

    if kind == DATE_AGREEMENT:
        return date_clauses(ctx)

    if kind == CONTACT_SHARE:
        # 2026-09-09: this used to interpolate ctx["channel"], which is
        # never set — the ceremony is scoped to the pair, not to one
        # handle — so clause 1 rendered "Your the channel requested
        # becomes visible". The placeholder is gone rather than filled:
        # one signature covers whichever channels you each accept, so
        # naming one of them would be the wrong claim even when it read
        # as a sentence.
        return _simple_clauses([
            ("What you are sharing",
             "Only the handles or numbers you each accept, one at a time. Neither of you sees "
             "anything until you have both signed."),
            ("Taking it back",
             "Either of you can undo this whenever you want. It hides the detail again. It "
             "cannot unsend a message already sent."),
            ("What it is for",
             "Reaching each other. Not for adding to a list, passing on, or looking each other "
             "up elsewhere."),
            ("No obligation",
             "A number is not a promise to reply, to reply quickly, or to keep replying. "
             "Neither of you owes the other a pace."),
        ])

    if kind == HOME_INVITE:
        return _simple_clauses([
            ("The invitation", "One visit, to the address confirmed in the invitation, at the "
                               "agreed time. Neither party is committing to anything beyond it."),
            ("Someone knows", "Both parties confirm a trusted contact outside this app has been "
                              "told where they will be and when they expect to leave."),
            ("Calling it off", "Either party may cancel at any point before or during, without "
                               "explanation and without it counting against them anywhere."),
            ("Boundaries stand", "Everything either party recorded about pace and boundaries "
                                 "applies here exactly as it does anywhere else."),
        ])

    if kind == RELATIONSHIP_ENTRY:
        return _simple_clauses([
            ("Exclusivity", "Both parties leave the weekly matching pool. Neither will be shown "
                            "to anyone else, and neither will be shown anyone else."),
            ("What begins", "Guru's four pillars start: airing and resolving differences, "
                            "sharing expenses, mediation when wanted, and keeping romance alive."),
            ("What this is not", "This is an agreement of understanding between two people, not "
                                 "a legal instrument, and it creates no financial or legal tie."),
            ("Leaving", "Either party may exit. Exiting opens a private conversation with Guru "
                        "and a cool-off period before returning to the pool."),
        ])

    next_name = ctx.get("next_stage_name") or "the next stage"
    return _simple_clauses([
        ("Both, or neither", f"Moving to {next_name} needs both of you. One opt-in advances "
                             "nothing, and nothing here is automatic."),
        ("What changes", ctx.get("what_changes") or
                         f"{next_name} layers new topics onto the same four pillars. The pillars "
                         "themselves do not change."),
        ("What does not", "Nothing about this checkpoint is irreversible, and reaching a stage "
                          "creates no obligation to reach the next one."),
        ("Honesty", "This checkpoint works only if both answers are honest. A checkpoint passed "
                    "to please the other person is worse than one not yet passed."),
    ])
