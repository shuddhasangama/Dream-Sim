@echo off
REM ═══════════════════════════════════════════════════════════════════
REM  Date agreement rebuilt against the sample playbook, intimacy
REM  questions paced, and every back link pointed at its real parent.
REM
REM  Stages with `git add -A`. A hand-written file list goes stale the
REM  moment a new file appears - which is exactly how conftest.py and
REM  four others missed commit 9f9adbb.
REM ═══════════════════════════════════════════════════════════════════
cd /d "%~dp0"

echo.
echo === Branch ===
git rev-parse --abbrev-ref HEAD

echo.
echo === Running the test suite (expect 953 passed) ===
REM DATABASE_URL must NOT be set: the suite silently switches to
REM PostgreSQL when it is, and 61 tests fail for reasons that look
REM unrelated to whatever you just changed.
REM smoke_test.py stays excluded: broken on master already.
set "DATABASE_URL="
python -m pytest -q --ignore=smoke_test.py
if errorlevel 1 (
  echo.
  echo Tests failed. Nothing has been committed.
  goto :fail
)

echo.
echo === Staging ===
git add -A
git status --short

echo.
echo === Committing ===
git commit -F commit-message-playbook.txt
if errorlevel 1 goto :fail

echo.
echo === Pulling before push ===
git pull --rebase
if errorlevel 1 (
  echo.
  echo The pull needs your attention. Resolve, then run:  git push
  goto :fail
)

echo.
echo === Pushing ===
git push
if errorlevel 1 goto :fail

echo.
echo Pushed. Railway will redeploy on its own.
echo Confirm the deploy picked THIS commit:  git log -1 --format=%%h
echo.
pause
exit /b 0

:fail
echo.
echo Stopped. Nothing was pushed.
pause
exit /b 1
