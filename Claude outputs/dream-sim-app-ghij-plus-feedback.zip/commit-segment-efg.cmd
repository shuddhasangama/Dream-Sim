@echo off
REM ── Segments E, F, G: the ceremony, the debrief, Guru's hub ──────────
REM Run the earlier commit scripts first if you have not already.
cd /d "%~dp0"

echo.
echo === Branch ===
git rev-parse --abbrev-ref HEAD

echo.
echo === Running the test suite (expect 699 passed) ===
python -m pytest -q --ignore=smoke_test.py
if errorlevel 1 (
  echo.
  echo Tests failed. Nothing has been committed.
  goto :fail
)

echo.
echo === Staging ===
git add ceremony.py guru.py test_ceremony.py test_guru.py test_segment_efg_routes.py ^
        app.py db.py disclosure.py test_disclosure.py ^
        schema.sql schema_postgres.sql static\style.css ^
        templates\ceremony.html templates\debrief.html templates\guru.html ^
        templates\base.html commit-segment-efg.cmd
git status --short

echo.
echo === Committing ===
git commit -F commit-message-efg.txt
if errorlevel 1 goto :fail

echo.
echo === Pulling before push (origin may be ahead) ===
git pull --rebase
if errorlevel 1 (
  echo.
  echo The pull needs your attention. Resolve, then run:  git push
  goto :fail
)

echo.
echo === Pushing ===
git push
if errorlevel 1 goto :fail

echo.
echo Pushed. Railway will redeploy on its own.
echo Confirm the deploy picked THIS commit:
echo    git log -1 --format=%%h
echo then match that short hash against the newest deploy in Railway.
echo.
pause
exit /b 0

:fail
echo.
echo Stopped.
pause
exit /b 1
