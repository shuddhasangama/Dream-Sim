@echo off
REM ═══════════════════════════════════════════════════════════════════
REM  Guru-brokered stage gate, /after-date, and the focused Guru hub.
REM
REM  Stages with `git add -A` rather than a file list. The previous
REM  helper listed files by hand and went stale the moment a new file
REM  appeared - the same failure drift-check.sql had.
REM ═══════════════════════════════════════════════════════════════════
cd /d "%~dp0"

echo.
echo === Branch ===
git rev-parse --abbrev-ref HEAD

echo.
echo === Running the test suite (expect 909 passed) ===
REM DATABASE_URL must NOT be set: the suite silently switches to
REM PostgreSQL when it is, and 61 tests fail for reasons that look
REM unrelated to whatever you just changed.
REM smoke_test.py stays excluded: broken on master already.
set "DATABASE_URL="
python -m pytest -q --ignore=smoke_test.py
if errorlevel 1 (
  echo.
  echo Tests failed. Nothing has been committed.
  goto :fail
)

echo.
echo === Staging ===
git add -A
git status --short

echo.
echo === Committing ===
git commit -F commit-message-guru-focus.txt
if errorlevel 1 goto :fail

echo.
echo === Pulling before push ===
git pull --rebase
if errorlevel 1 (
  echo.
  echo The pull needs your attention. Resolve, then run:  git push
  goto :fail
)

echo.
echo === Pushing ===
git push
if errorlevel 1 goto :fail

echo.
echo Pushed. Railway will redeploy on its own.
echo Confirm the deploy picked THIS commit:  git log -1 --format=%%h
echo.
pause
exit /b 0

:fail
echo.
echo Stopped. Nothing was pushed.
pause
exit /b 1
