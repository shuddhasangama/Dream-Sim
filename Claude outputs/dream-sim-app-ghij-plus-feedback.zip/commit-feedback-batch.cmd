@echo off
REM ── Schema guards, explicit terms, debrief timing, cancellation,
REM    Stats split, localisation, REACH honesty, date alignment,
REM    plus Journey Segments G, H, I and J ────────────────────────────
cd /d "%~dp0"

echo.
echo === Branch ===
git rev-parse --abbrev-ref HEAD

echo.
echo === Running the test suite (expect 843 passed) ===
REM DATABASE_URL must NOT be set here: the suite silently switches to
REM PostgreSQL when it is, and 61 tests fail for reasons that look
REM unrelated to whatever you just changed.
set "DATABASE_URL="
python -m pytest -q --ignore=smoke_test.py
if errorlevel 1 (
  echo.
  echo Tests failed. Nothing has been committed.
  goto :fail
)

echo.
echo === Staging ===
git add locale_defaults.py date_alignment.py test_date_alignment.py ^
        db.py test_db_reconcile.py drift-check.sql conftest.py ^
        progress.py test_progress.py test_segment_ghij_routes.py demo.py ^
        templates\married.html templates\admin_pairs.html ^
        templates\escalations.html templates\gate.html templates\journey.html ^
        templates\base.html ^
        ceremony.py dateplan.py payments.py matching.py onboarding.py ^
        disclosure.py guru.py app.py schema.sql schema_postgres.sql ^
        test_schema_postgres.py test_ceremony.py test_dateplan.py ^
        test_matching.py test_onboarding.py test_segment_efg_routes.py ^
        static\style.css templates\ceremony.html templates\debrief.html ^
        templates\plan.html templates\onboard_stats.html templates\reach.html ^
        templates\align.html commit-feedback-batch.cmd
git status --short

echo.
echo === Committing ===
git commit -F commit-message-feedback.txt
if errorlevel 1 goto :fail

echo.
echo === Pulling before push ===
git pull --rebase
if errorlevel 1 (
  echo.
  echo The pull needs your attention. Resolve, then run:  git push
  goto :fail
)

echo.
echo === Pushing ===
git push
if errorlevel 1 goto :fail

echo.
echo Pushed. Railway will redeploy on its own.
echo Confirm the deploy picked THIS commit:  git log -1 --format=%%h
echo.
pause
exit /b 0

:fail
echo.
echo Stopped.
pause
exit /b 1
