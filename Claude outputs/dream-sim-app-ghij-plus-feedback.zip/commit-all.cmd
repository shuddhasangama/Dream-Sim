@echo off
REM ═══════════════════════════════════════════════════════════════════
REM  ONE commit for everything since Segment A.
REM
REM  Segment A is already committed and merged into master. Segments
REM  B/C/D were written but never committed, and the later refinements
REM  edit the same files, so splitting them into two commits would put
REM  refinement content under a "Segment B/C/D" message. One commit is
REM  both simpler and more honest about what happened.
REM
REM  IGNORE the older helpers: commit-segment-bcd.cmd and
REM  commit-refinements.cmd. This replaces both.
REM ═══════════════════════════════════════════════════════════════════

cd /d "%~dp0"

echo.
echo === Moving to the segment-bcd branch ===
REM It already exists and points at the same commit as master, so the
REM uncommitted work carries across with no possibility of conflict.
git checkout segment-bcd
if errorlevel 1 goto :fail

echo.
echo === Running the test suite ===
REM smoke_test.py stays excluded: it is broken on master already,
REM importing load_users from generate_users, which does not exist.
python -m pytest -q --ignore=smoke_test.py
if errorlevel 1 (
  echo.
  echo Tests failed. Nothing has been committed.
  goto :fail
)

echo.
echo === Untracking the one-off commit helpers ===
git rm --cached commit-segment-a.cmd >nul 2>&1

echo.
echo === Staging everything ===
git add -A
git status --short

echo.
echo === Committing ===
git commit -F commit-message-all.txt
if errorlevel 1 goto :fail

echo.
echo Committed on segment-bcd.
echo.
echo   Review:            git show --stat
echo   Push the branch:   git push -u origin segment-bcd
echo   Or go to master:   git checkout master ^&^& git merge segment-bcd ^&^& git push
echo.
pause
exit /b 0

:fail
echo.
echo Stopped. Nothing was committed.
pause
exit /b 1
