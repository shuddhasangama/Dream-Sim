@echo off
REM ── Segments B, C, D: run the tests, commit onto the same branch ──────
REM Run commit-segment-a.cmd FIRST if you have not already.
REM This stops before pushing so you can review the diff.

cd /d "%~dp0"

echo.
echo === Branch ===
git rev-parse --abbrev-ref HEAD

echo.
echo === Running the test suite ===
REM smoke_test.py is excluded: it is broken on master already, importing
REM load_users from generate_users, which does not exist.
python -m pytest -q --ignore=smoke_test.py
if errorlevel 1 (
  echo.
  echo Tests failed. Nothing has been committed.
  goto :fail
)

echo.
echo === Staging ===
git add bgv.py demo.py payments.py test_bgv.py test_demo.py test_payments.py ^
        app.py db.py schema.sql schema_postgres.sql static\style.css ^
        templates\base.html templates\_demo_bar.html templates\verify.html ^
        templates\pay.html templates\demo_partner_failed.html ^
        commit-segment-bcd.cmd
git status --short

echo.
echo === Committing ===
git commit -F commit-message-bcd.txt
if errorlevel 1 goto :fail

echo.
echo Committed. Review with:  git show --stat
echo Push with:               git push -u origin segment-a-front-door
echo.
pause
exit /b 0

:fail
echo.
echo Stopped. Nothing was committed.
pause
exit /b 1
