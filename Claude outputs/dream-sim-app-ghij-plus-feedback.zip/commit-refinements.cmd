@echo off
REM ── Verification fields, new Stats, disclosure timing ────────────────
REM Run the earlier commit scripts first if you have not already.
cd /d "%~dp0"

echo.
echo === Branch ===
git rev-parse --abbrev-ref HEAD

echo.
echo === Running the test suite ===
python -m pytest -q --ignore=smoke_test.py
if errorlevel 1 (
  echo.
  echo Tests failed. Nothing has been committed.
  goto :fail
)

echo.
echo === Staging ===
git add disclosure.py test_disclosure.py bgv.py test_bgv.py onboarding.py test_onboarding.py ^
        generate_users.py test_generate_users.py demo.py test_demo.py app.py ^
        static\style.css templates\base.html templates\chemistry.html templates\boundaries.html ^
        templates\expectations.html templates\vibes.html templates\locked.html ^
        templates\onboard_stats.html templates\onboard_done.html templates\plan.html ^
        commit-refinements.cmd
git status --short

echo.
echo === Committing ===
git commit -F commit-message-refinements.txt
if errorlevel 1 goto :fail

echo.
echo Committed. Review:  git show --stat
echo Push:               git push
echo.
pause
exit /b 0

:fail
echo.
echo Stopped. Nothing was committed.
pause
exit /b 1
